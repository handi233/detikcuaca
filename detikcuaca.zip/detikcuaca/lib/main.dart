import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:geolocator/geolocator.dart';

Future<Position> _determinePosition() async {
  bool serviceEnabled;
  LocationPermission permission;

  // Cek apakah service lokasi aktif
  serviceEnabled = await Geolocator.isLocationServiceEnabled();
  if (!serviceEnabled) {
    // Jika tidak aktif, bisa kasih notif atau minta user aktifkan
    return Future.error('Location services are disabled.');
  }

  permission = await Geolocator.checkPermission();
  if (permission == LocationPermission.denied) {
    permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.denied) {
      return Future.error('Location permissions are denied');
    }
  }

  if (permission == LocationPermission.deniedForever) {
    return Future.error('Location permissions are permanently denied.');
  }

  // Kalau sudah diberi izin, ambil posisi saat ini
  return await Geolocator.getCurrentPosition();
}

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(home: const WeatherPage());
  }
}

class WeatherPage extends StatefulWidget {
  const WeatherPage({super.key});

  @override
  State<WeatherPage> createState() => _WeatherPageState();
}

class _WeatherPageState extends State<WeatherPage> {
  final TextEditingController _controller = TextEditingController();
  String _city = '';
  final String _apiKey = 'f13bf79f3f0f6cb76a7d8c3100fb13f8';

  String _weather = '';
  String _temperature = '';
  String _iconCode = '';
  bool _isLoading = false;

  Future<void> _fetchWeather() async {
    if (_city.isEmpty) return;

    setState(() {
      _isLoading = true;
      _weather = '';
      _temperature = '';
      _iconCode = '';
    });

    final url =
        'https://api.openweathermap.org/data/2.5/weather?q=$_city&appid=$_apiKey&units=metric';

    try {
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          _weather = data['weather'][0]['main'];
          _temperature = data['main']['temp'].toString();
          _iconCode = data['weather'][0]['icon'];
        });
      } else {
        setState(() {
          _weather = 'Kota tidak ditemukan';
          _temperature = '';
          _iconCode = '';
        });
      }
    } catch (e) {
      setState(() {
        _weather = 'Terjadi kesalahan';
        _temperature = '';
        _iconCode = '';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _updateCity() {
    setState(() {
      _city = _controller.text.trim();
    });
    _fetchWeather();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Perkirakan Cuaca Today')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _controller,
              decoration: const InputDecoration(
                labelText: 'Masukkan nama kota',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _updateCity,
              child: const Text('Cek Cuaca'),
            ),
            const SizedBox(height: 32),
            if (_isLoading) const Center(child: CircularProgressIndicator()),
            if (!_isLoading && _weather.isNotEmpty)
              Card(
                elevation: 4,
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    children: [
                      if (_iconCode.isNotEmpty)
                        Image.network(
                          'http://openweathermap.org/img/wn/${_iconCode}@2x.png',
                          width: 80,
                          height: 80,
                        ),
                      const SizedBox(width: 16),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Cuaca: $_weather',
                            style: const TextStyle(fontSize: 20),
                          ),
                          Text(
                            'Suhu: $_temperature °C',
                            style: const TextStyle(fontSize: 20),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
