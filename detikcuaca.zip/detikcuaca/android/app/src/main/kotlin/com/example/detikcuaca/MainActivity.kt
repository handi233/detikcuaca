package com.example.detikcuaca

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
